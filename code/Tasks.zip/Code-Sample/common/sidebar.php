<div id="ribbon" class="sidebar">

    Reminders
    
    <ul>
         <li>Your list automatically saves</li>
         <li>Double-click list items to edit them</li>
    </ul>

</div>