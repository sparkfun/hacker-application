<?php
    include_once "common/base.php";
    $pageTitle = "Reset Pending";
    include_once "common/header.php";
?>

        <h2>Password Reset Requested</h2>
        <p>Check your email to finish the reset process.</p>
<?php
    include_once "common/sidebar.php";
    include_once "common/footer.php";
?>