<?php

    // Database credentials
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'cl_db');

    // HTML Whitelist
    define('WHITELIST', '<b><i><strong><em><a>');

?>