package data;

public interface ParameterSet {

}
