package road;

public interface Intersection extends RoadWay {

}
