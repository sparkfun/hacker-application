package road;

public interface RoadSegment extends RoadWay {
	//Return the length of the road segment
	public double length();

}
