package road;

import model.Agent;

public interface Source extends Agent{
	public void run();

}
