package agent;

public interface Agent {
  public void run();
  public void run(double time);
}
