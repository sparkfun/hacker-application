package model;

public class Light {

	public boolean getState()
	{
		return true;
	}
}
