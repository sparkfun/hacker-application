package road;

public interface roadSegment extends RoadWay {
	//Return the length of the road segment
	public double length();

}
