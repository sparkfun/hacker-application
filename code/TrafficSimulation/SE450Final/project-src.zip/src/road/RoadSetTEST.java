package road;

import static org.junit.Assert.*;

import org.junit.Test;

public class RoadSetTEST {

	@Test
	public void test() {
		assertTrue(true);
	}

}
