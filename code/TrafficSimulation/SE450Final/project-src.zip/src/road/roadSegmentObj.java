package road;

public class roadSegmentObj implements roadSegment{
	double _length;
	
	public roadSegmentObj(double length)
	{
		_length = length;
	}

	public double length()
	{
		return _length;
	}
}
