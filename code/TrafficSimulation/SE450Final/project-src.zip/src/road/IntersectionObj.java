package road;

public final class IntersectionObj implements Intersection{
	public double _length;
	public double _NSStartPosition;
	public double _EWStartPosition;
	public IntersectionObj(double length)
	{
		_length = length;
	}
	
	public double length()
	{
		return _length;
	}
	
	public void setNSStartPosition(double position)
	{
		_NSStartPosition = position;
	}
	
	public double NSStartPosition()
	{
		return _NSStartPosition;
	}
	
	public void setEWStartPosition(double position)
	{
		_EWStartPosition = position;
	}
	
	public double EWStartPosition()
	{
		return _EWStartPosition;
	}
}
