package road;

public interface RoadWay {

	public double length();
}
