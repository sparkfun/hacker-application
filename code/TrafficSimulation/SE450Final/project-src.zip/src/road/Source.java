package road;

import agent.Agent;

public interface Source extends Agent{
	public void run();

}
