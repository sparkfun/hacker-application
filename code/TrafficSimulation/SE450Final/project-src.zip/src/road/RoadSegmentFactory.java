package road;

public class RoadSegmentFactory {
	private RoadSegmentFactory(){}
	static public roadSegmentObj newRoadSegment(double length)
	{
		return new roadSegmentObj(length);
	}
}
