package road;
import car.CarObj;

import agent.TimeServerQueue;
import data.*;

public class SourceObj implements Source{
	static TimeServerQueue _time;
	Parameters _parameters;
	RoadSet _road;
	
	public SourceObj(Parameters parameters, RoadSet road)
	{
		System.out.printf("\t\tInitializing Road Source\n");
		_parameters = parameters;
		_time = _parameters.timeServer();
		_road = road;
	}
	public void run()
	{
		//Initialize a new carObj on the source's road, needs to enqueue the car in
		//the queue in that road.
		if ((_time.currentTime() - _parameters.startTime()) < _parameters.runTime())
		{
		System.out.printf("Generating car\n");
		CarObj newCar = new CarObj(_parameters, _road);
		_time.enqueue(_time.currentTime(), newCar);
		
		}
		//Enqueue the source in the time server for the next wake
		_time.enqueue(_parameters.carEntryRate() + _time.currentTime(), this);
		
	}
}
