package road;
import java.util.AbstractList;
import java.util.ArrayList;
import agent.TimeServerQueue;
import car.CarObj;
import data.Parameters;

public final class RoadSet implements Road {
	
	static AbstractList<RoadWay> _segments = new ArrayList<RoadWay>();
	RoadWay[] _intersections;
	double _segmentLength;
	double _intersectionLength;
	int _numIntersections;
	SourceObj _source;
	TimeServerQueue _time;
	static AbstractList<CarObj> _cars = new ArrayList<CarObj>();
	public enum direction{North, South, East, West}
	static direction _sourceLocation;
	public Parameters _parameters;
	
	public RoadSet(int numIntersections, RoadWay[] intersections, direction direction, Parameters parameters)
	{
		_parameters = parameters;
		_segmentLength = _parameters.roadSegmentLength();
		_numIntersections = numIntersections;
		_time = _parameters.timeServer();
		_source = new SourceObj(_parameters, this);
		_sourceLocation = direction;
		_intersections = intersections;
		
	}
	
	public void initialize()
	{
		double roadLength = 0;
		addRoadSegment(new roadSegmentObj(_segmentLength));
		System.out.printf("\tInitializing road\n");
		roadLength += _segmentLength;
		for (int i = 0; i < _numIntersections; i++)
		{
			if (_intersections[i] instanceof IntersectionObj)
			{
				if (_sourceLocation == direction.North || _sourceLocation == direction.South)
					((IntersectionObj) _intersections[i]).setNSStartPosition(roadLength);
				else
					((IntersectionObj) _intersections[i]).setEWStartPosition(roadLength);
				addIntersection((IntersectionObj) _intersections[i]);
				roadLength += _intersections[i].length();
			}
			else
				throw new IllegalArgumentException("Expected IntersectionObj");
			addRoadSegment(new roadSegmentObj(_segmentLength));
			roadLength+= _segmentLength;
		}
	}
	
	private void addRoadSegment(roadSegmentObj newSegment)
	{
		_segments.add(newSegment);
	}
	
	private void addIntersection(IntersectionObj newIntersection)
	{
		_segments.add(newIntersection);
	}
	
	public void run(){}
	
	public int size()
	{
		return _numIntersections + 1;
	}
	
	public AbstractList<RoadWay> segments()
	{
		return (AbstractList<RoadWay>)_segments;
	}
	
	public SourceObj source()
	{
		return _source;
	}
	
	public void enqueueCar(CarObj car)
	{
		_cars.add(car);
	}
	
	public IntersectionObj nextIntersection(CarObj car)
	{
		IntersectionObj nextIntersection = null;
		double cumulativeLength = 0;
		int canary = 1;
		int setVariable = 0;
		for (RoadWay currentSegment : _segments)
		{
			cumulativeLength += currentSegment.length();
			if (cumulativeLength > car.currentPosition())
			{
				canary = 0;
			}
			if (canary == 0 && (currentSegment instanceof IntersectionObj) && setVariable == 0)
			{
				nextIntersection = (IntersectionObj) currentSegment;
			}
		}
		return nextIntersection;
	}
	
	public double nextObstacle(CarObj car)
	{
		double distanceToNextCar = _parameters.carBrakeDistance() + 1;
		double distanceToNextIntersection;
		CarObj nextCar = null;
		if (_cars.indexOf(car) +1 < _cars.size())
		{
			nextCar =_cars.get(_cars.indexOf(car) + 1);
			distanceToNextCar = nextCar.currentPosition() - car.currentPosition();
		}
		IntersectionObj nextIntersection = nextIntersection(car);
		if ((_sourceLocation == direction.North || _sourceLocation == direction.South) && nextIntersection != null)
			distanceToNextIntersection = nextIntersection.NSStartPosition() - car.currentPosition();
		else if (nextIntersection != null)
			distanceToNextIntersection = nextIntersection.EWStartPosition() - car.currentPosition();
		else
			return distanceToNextCar;
		return Math.min(distanceToNextCar, distanceToNextIntersection);
	}
}
