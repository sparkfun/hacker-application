package main;

import main.Control;
import ui.UI;


public class Main {
	  private Main() {}
	  public static void main(String[] args) {
	    UI ui;
	    if (Math.random() <= 0.5) 

	    	ui = new ui.TextUI();
	    else
	    	ui = new ui.PopupUI();

	    Control control = new Control(ui);
	    control.run();
	  }
	}
