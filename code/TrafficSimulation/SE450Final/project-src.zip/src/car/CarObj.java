package car;

import data.*;
import agent.TimeServerQueue;
import road.RoadSet;

public final class CarObj implements Car{
	
	//Need to pass the instantiation of the Time Server down instead of pulling from Parameters class.
	double _length;
	double _maxVelocity;
	double _brakeDistance;
	double _stopDistance;
	static TimeServerQueue _timeServer;
	double _currentPosition = 0;
	RoadSet _road;
	GridConstructor _grid;
	Parameters _parameters;
	
	//TODO Need to initialize the car in source.  Write an init function and call it
	//in source after the car is created.  Need to get the time server for a specific instance.
	//
	
	public CarObj(Parameters parameters, RoadSet road)
	{
		_parameters = parameters;
		_timeServer = _parameters.timeServer();
		_length = _parameters.carLength();
		_maxVelocity = _parameters.carMaxVelocity();
		_brakeDistance = _parameters.carBrakeDistance();
		_stopDistance = _parameters.carStopDistance();
		_road = road;
	}
	
	public double length()
	{
		return _length;
	}
	
	public double maxVelocity()
	{
		return _maxVelocity;
	}
	
	public double brakeDistance()
	{
		return _brakeDistance;
	}
	
	public double stopDistance()
	{
		return _stopDistance;
	}
	
	public double currentPosition()
	{
		return _currentPosition;
	}
	

	
	public void run()
	{
		//Determine what the cars position will be when next waking.
		if (_timeServer.currentTime() - _parameters.startTime() < _parameters.runTime())
		{
		double velocity = (_maxVelocity / (_brakeDistance - _stopDistance))
                * (_road.nextObstacle(this) - _stopDistance);
		System.out.printf("I'm a car!  My position is" + Double.toString(_currentPosition) + " and the time is " + _timeServer.currentTime() + "\n");
		_currentPosition += velocity * _parameters.timeStep();
		_timeServer.enqueue(_parameters.timeStep() + _timeServer.currentTime(), this);
		}
	}
}
