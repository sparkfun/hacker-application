package car;

import static org.junit.Assert.*;

import org.junit.Test;
import data.Parameters;
import road.*;

public class CarObjTEST {
	Parameters parameters = new Parameters();
	RoadWay[] intersections = new RoadWay[0];
	RoadSet road = new RoadSet(0, intersections, RoadSet.direction.North, parameters);
	@Test
	public void test() {
		CarObj car = new CarObj(parameters, road);
		assertTrue(5.0 < car.length() && car.length() < 10.0);
		assertTrue(10 < car.maxVelocity() && car.maxVelocity() < 30);
		assertTrue(0.5 < car.stopDistance() && car.stopDistance() < 5.0);
		assertTrue(9.0 < car.brakeDistance() && car.brakeDistance() < 10.0);
	}
}
