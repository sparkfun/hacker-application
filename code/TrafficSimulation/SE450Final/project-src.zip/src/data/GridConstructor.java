package data;

import agent.TimeServerQueue;
import road.RoadWay;
import agent.*;

import road.RoadSet;
import road.IntersectionObj;

public class GridConstructor {
	private RoadSet[][] roads;
	public static TimeServerQueue _timeServer;
	public static Parameters _parameters;
	//public static double _startTime;
	
	public GridConstructor(Parameters parameters)
	{
		_parameters = parameters;
		_timeServer = parameters.timeServer();
		roads = new RoadSet[2][Math.max(_parameters.gridSize()[0], _parameters.gridSize()[1])];
		System.out.printf("Initializing Intersections\n");
		RoadWay[][] intersections = new RoadWay[_parameters.gridSize()[0]][_parameters.gridSize()[1]];
		for (int i = 0; i < _parameters.gridSize()[0]; i++)
			for (int j = 0; j < _parameters.gridSize()[1]; j++)
			{
				intersections[i][j] = new IntersectionObj(_parameters.intersectionLength());
			}
		//initialize N/S roads
		System.out.printf("Initializing North/South Roads\n");
		for (int i = 0; i < _parameters.gridSize()[0]; i++)
		{
			//TODO Determine a way to alternate direction if parameters call for it.
			RoadWay[] roadIntersections = new RoadWay[_parameters.gridSize()[1]];
			for (int j = 0; j < _parameters.gridSize()[1]; j++)
			{
				roadIntersections[j] = intersections[i][j];
			}
			roads[0][i] = new RoadSet(_parameters.gridSize()[1], roadIntersections, RoadSet.direction.North, parameters);
			roads[0][i].initialize();
			_timeServer.enqueue(_timeServer.currentTime() ,(Agent)roads[0][i].source());
		}
		
		System.out.printf("Initializing East/West Roads\n");
		for (int j = 0; j < _parameters.gridSize()[1]; j++)
		{
			RoadWay[] roadIntersections = new RoadWay[_parameters.gridSize()[0]];
			for (int i = 0; i < _parameters.gridSize()[0]; i++)
			{
				roadIntersections[i] = intersections[i][j];
			}
			roads[1][j] = new RoadSet(_parameters.gridSize()[0], roadIntersections, RoadSet.direction.East, parameters);
			roads[1][j].initialize();
			_timeServer.enqueue(_timeServer.currentTime(), (Agent)roads[1][j].source());
		}
		_timeServer.run(_parameters.runTime());
		_parameters.setStartTime(_timeServer.currentTime());

	}
	
	public RoadSet returnRoad(RoadSet.direction direction, int roadNumber)
	{
		int index;
		if (direction == RoadSet.direction.North || direction == RoadSet.direction.South)
			index = 0;
		else
			index = 1;
		return roads[index][roadNumber];
	}	
}
