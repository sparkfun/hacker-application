package light;

public class lightObj implements light{
	private double _greenTime;
	private double _yellowTime;
	lightObj(double greenTime, double yellowTime)
	{
		_greenTime = greenTime;
		_yellowTime = yellowTime;
	}
	
	public double greenTime()
	{
		return _greenTime;
	}
	
	public double yellowTime()
	{
		return _yellowTime;
	}
	
	public void run(){}
}
